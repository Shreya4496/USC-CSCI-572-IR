Instructions to run the PHP file


1. Place the solr-php-client in the same directory as index.php.
2. Place the URLtoHTML_latimes_news.csv in the same folder as the index.php file. 
3. Setup an Apache Server using XAMPP (Instructions given in the report).
4. Run the Solr backend service as given in the specification.
5. Open index.php on any browser.